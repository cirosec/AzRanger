// ─── Helpers ────────────────────────────────────────────────────────────────

function getColor(value, max_value) {
  const hue = ((1 - value / max_value) * 120).toString(10);
  return `hsl(${hue},100%,50%)`;
}

// Returns { label: "[High]", severity: "high" } for a given RiskScore
function riskScoreToSeverity(score) {
  if (score === 10)          return { label: "[Critical]", severity: "critical" };
  if (score > 6)             return { label: "[High]",     severity: "high"     };
  if (score > 3)             return { label: "[Medium]",   severity: "medium"   };
  if (score > 0)             return { label: "[Low]",      severity: "low"      };
  /* score === 0 */          return { label: "[None]",     severity: "none"     };
}

// Returns { text: "Risklevel: High", chartValue: 2.5 } for gauge rendering
function getRiskLevelInfo(highestRisk) {
  if (highestRisk === 10)         return { text: "Risklevel: Critical", chartValue: 3.5 };
  if (highestRisk > 6)            return { text: "Risklevel: High",     chartValue: 2.5 };
  if (highestRisk > 3)            return { text: "Risklevel: Medium",   chartValue: 1.5 };
  if (highestRisk > 0)            return { text: "Risklevel: Low",      chartValue: 0.5 };
  /* highestRisk === 0 */         return { text: "Risklevel: None",     chartValue: 0   };
}

// Wraps a text field with a label, or returns "" if value is null
function renderTextField(label, value) {
  if (value == null) return "";
  return `<div class="az-field-label">${label}</div><div>${value}</div>`;
}

// Wraps a URL field with a label, or returns "" if url is null
function renderLinkField(label, url) {
  if (url == null) return "";
  return `<div class="az-field-label">${label}</div><div><a href="${url}" target="_blank">${url}</a></div>`;
}

// Creates a semi-circular doughnut gauge Chart.js config
function createGaugeConfig(value, max, color) {
  return {
    type: 'doughnut',
    data: {
      labels: [],
      datasets: [{
        data: [value, max - value],
        backgroundColor: [color, 'rgba(255, 255, 255, 0.08)'],
        borderWidth: 0
      }]
    },
    options: {
      responsive: false,
      maintainAspectRatio: false,
      cutoutPercentage: 85,
      rotation: -90,
      circumference: 180,
      tooltips:  { enabled: false },
      legend:    { display: false },
      animation: { animateRotate: true, animateScale: false },
      title:     { display: false }
    }
  };
}

// Appends an accordion section to a target view element
function appendAccordionSection(targetId, template, topic, containerID, accordionID, items) {
  let x = template.replace(/{{Topic}}/ig, topic);
  x = x.replace(/{{ContainerID}}/ig, containerID);
  x = x.replace(/{{accordionSection}}/ig, accordionID);
  $(`#${targetId}`).append(x);
  $(`#${accordionID}`).append(items);
}


// ─── Accordion item builder ──────────────────────────────────────────────────

function createAccordionItem(element, accordionSection) {
  const { label: criticality, severity } = riskScoreToSeverity(element.RiskScore);

  const serviceTag = element.Service != null
    ? `<span class="az-service-tag">${element.Service}</span>`
    : '';

  const cisHtml = element.CISDocument != null
    ? `<div class="az-field-label">CIS Reference</div>` +
      `<div class="az-cis-badges">` +
        `<span class="az-cis-badge">${element.CISDocument}</span>` +
        `<span class="az-cis-badge">&sect;${element.Section}</span>` +
        `<span class="az-cis-badge">Level ${element.Level}</span>` +
        `<span class="az-cis-badge">v${element.Version}</span>` +
      `</div>`
    : '';

  let affectedHtml = '';
  if (element.AffectedItems != null) {
    const count = element.AffectedItems.length;
    const limit = 50;
    const rows = element.AffectedItems.slice(0, limit).map(item => {
      const id   = item['Id']   ?? '';
      const name = item['Name'] ?? '';
      return `<tr><td class="az-affected-id">${id}</td><td>${name}</td></tr>`;
    }).join('');
    const moreHint = count > limit
      ? `<p class="az-affected-more">... and ${count - limit} more</p>`
      : '';
    const sn = element.ShortName;
    affectedHtml =
      `<div class="accordion az-affected-accordion" id="accordion_affectedItem_${sn}">` +
        `<div class="accordion-item">` +
          `<h2 class="accordion-header">` +
            `<button class="accordion-button collapsed az-affected-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse_affectedItem_${sn}">` +
              `Affected Objects <span class="az-affected-count">${count}</span>` +
            `</button>` +
          `</h2>` +
          `<div id="collapse_affectedItem_${sn}" class="accordion-collapse collapse" data-bs-parent="#accordion_affectedItem_${sn}">` +
            `<div class="accordion-body p-0">` +
              `<table class="table table-sm az-affected-table mb-0">` +
                `<thead><tr><th>ID</th><th>Name</th></tr></thead>` +
                `<tbody>${rows}</tbody>` +
              `</table>` +
              moreHint +
            `</div>` +
          `</div>` +
        `</div>` +
      `</div>`;
  }

  let x = $.trim($('#RuleResultTemplate').html());
  x = x.replace(/{{ShortDescription}}/ig, element.ShortDescription);
  x = x.replace(/{{Criticality}}/ig,      criticality);
  x = x.replace(/{{Severity}}/ig,         severity);
  x = x.replace(/{{ServiceTag}}/ig,       serviceTag);
  x = x.replace(/{{LongDescription}}/ig,  renderTextField('Description', element.LongDescription));
  x = x.replace(/{{Risk}}/ig,             renderTextField('Risk',        element.Risk));
  x = x.replace(/{{Reason}}/ig,           renderTextField('Reason',      element.Reason));
  x = x.replace(/{{Solution}}/ig,         renderTextField('Solution',    element.Solution));
  x = x.replace(/{{PortalUrl}}/ig,        renderLinkField('Portal URL',  element.PortalUrl));
  x = x.replace(/{{ReferenceLink}}/ig,    renderLinkField('Reference',   element.ReferenceLink));
  x = x.replace(/{{CISInfos}}/ig,         cisHtml);
  x = x.replace(/{{AffectedItems}}/ig,    affectedHtml);
  x = x.replace(/{{acordionSection}}/ig,  accordionSection);
  x = x.replace(/{{collapseID}}/ig,       'collapseAcordion_' + element.ShortName);
  return x;
}


// ─── Main rendering ──────────────────────────────────────────────────────────

function fillFindings() {
  $("#tenantid").html("Tenant ID: " + tenantData.TenantId);
  $("#userid").html(
    tenantData.Username.includes("@")
      ? "Username: " + tenantData.Username
      : "Application ID: " + tenantData.Username
  );

  Chart.overrides.doughnut.plugins.legend.display = false;

  const template = $.trim($('#AccordionTemplate').html());

  // Buckets
  const m365_findings      = [], azure_findings      = [];
  const m365_nofindings    = [], azure_nofindings    = [];
  const m365_notApplicable = [], azure_notApplicable = [];
  const m365_error         = [], azure_error         = [];

  // Accordion section IDs
  const ACC = {
    m365_findings:      "accordionM365_Findings",
    m365_nofindings:    "accordionM365_NoFindings",
    m365_notApplicable: "accordionM365_NotApplicable",
    m365_errors:        "accordionM365_Errors",
    azure_findings:     "accordionAzure_Findings",
    azure_nofindings:   "accordionAzure_NoFindings",
    azure_notApplicable:"accordionAzure_NotApplicable",
    azure_errors:       "accordionAzure_Errors",
  };

  // Score accumulators
  let m365_maxPoints = 0, m365_achieved_points = 0, m365_highest_risk = 0;
  let azure_maxPoints = 0, azure_achieved_points = 0, azure_highest_risk = 0;
  let m365_count_critical = 0, m365_count_high = 0, m365_count_medium = 0, m365_count_low = 0;
  let azure_count_critical = 0, azure_count_high = 0, azure_count_medium = 0, azure_count_low = 0;

  function sortByRisk(arr) {
    return arr.slice().sort((a, b) => b.RiskScore - a.RiskScore);
  }

  // ── Findings ──
  if (reportData.Finding != null) {
    sortByRisk(reportData.Finding).forEach(el => {
      if (el.ShortDescription == null) return;
      if (el.Scope === "Azure") {
        azure_findings.push(createAccordionItem(el, ACC.azure_findings));
        azure_maxPoints       += el.RiskScore;
        azure_achieved_points += el.RiskScore;
        if (el.RiskScore > azure_highest_risk) azure_highest_risk = el.RiskScore;
        if (el.RiskScore === 10)   azure_count_critical++;
        else if (el.RiskScore > 6) azure_count_high++;
        else if (el.RiskScore > 3) azure_count_medium++;
        else if (el.RiskScore > 0) azure_count_low++;
      } else {
        m365_findings.push(createAccordionItem(el, ACC.m365_findings));
        m365_maxPoints       += el.RiskScore;
        m365_achieved_points  += el.RiskScore;
        if (el.RiskScore > m365_highest_risk) m365_highest_risk = el.RiskScore;
        if (el.RiskScore === 10)   m365_count_critical++;
        else if (el.RiskScore > 6) m365_count_high++;
        else if (el.RiskScore > 3) m365_count_medium++;
        else if (el.RiskScore > 0) m365_count_low++;
      }
    });

    if (m365_findings.length > 0)
      appendAccordionSection("M365-Mainview", template, "Finding", "M365_Finding_Container", ACC.m365_findings, m365_findings);
    if (azure_findings.length > 0)
      appendAccordionSection("Azure-Mainview", template, "Finding", "Azure_Finding_Container", ACC.azure_findings, azure_findings);

    // Stat tiles
    $("#m365_stat_findings").text(m365_findings.length);
    $("#m365_stat_critical").text(m365_count_critical);
    $("#m365_stat_high").text(m365_count_high);
    $("#m365_stat_medium").text(m365_count_medium);
    $("#m365_stat_low").text(m365_count_low);

    $("#azure_stat_findings").text(azure_findings.length);
    $("#azure_stat_critical").text(azure_count_critical);
    $("#azure_stat_high").text(azure_count_high);
    $("#azure_stat_medium").text(azure_count_medium);
    $("#azure_stat_low").text(azure_count_low);
  }

  // ── Not Applicable ──
  if (reportData.NotApplicable != null) {
    sortByRisk(reportData.NotApplicable).forEach(el => {
      if (el.ShortDescription == null) return;
      if (el.Scope === "Azure") {
        azure_notApplicable.push(createAccordionItem(el, ACC.azure_notApplicable));
        azure_maxPoints += el.RiskScore;
      } else {
        m365_notApplicable.push(createAccordionItem(el, ACC.m365_notApplicable));
        m365_maxPoints += el.RiskScore;
      }
    });
    if (m365_notApplicable.length > 0)
      appendAccordionSection("M365-Mainview", template, "Not Applicable", "M365_NotApplicable_Container", ACC.m365_notApplicable, m365_notApplicable);
    if (azure_notApplicable.length > 0)
      appendAccordionSection("Azure-Mainview", template, "Not Applicable", "Azure_NotApplicable_Container", ACC.azure_notApplicable, azure_notApplicable);
  }

  // ── No Finding ──
  if (reportData.NoFinding != null) {
    sortByRisk(reportData.NoFinding).forEach(el => {
      if (el.ShortDescription == null) return;
      if (el.Scope === "Azure") {
        azure_nofindings.push(createAccordionItem(el, ACC.azure_nofindings));
        azure_maxPoints += el.RiskScore;
      } else {
        m365_nofindings.push(createAccordionItem(el, ACC.m365_nofindings));
        m365_maxPoints += el.RiskScore;
      }
    });
    if (m365_nofindings.length > 0)
      appendAccordionSection("M365-Mainview", template, "No Finding", "M365_NoFinding_Container", ACC.m365_nofindings, m365_nofindings);
    if (azure_nofindings.length > 0)
      appendAccordionSection("Azure-Mainview", template, "No Finding", "Azure_NoFinding_Container", ACC.azure_nofindings, azure_nofindings);
  }

  // ── Errors ──
  if (reportData.Error != null) {
    sortByRisk(reportData.Error).forEach(el => {
      if (el.ShortDescription == null) return;
      if (el.Scope === "Azure")
        azure_error.push(createAccordionItem(el, ACC.azure_errors));
      else
        m365_error.push(createAccordionItem(el, ACC.m365_errors));
    });
    if (m365_error.length > 0)
      appendAccordionSection("M365-Mainview", template, "Error", "M365_Error_Container", ACC.m365_errors, m365_error);
    if (azure_error.length > 0)
      appendAccordionSection("Azure-Mainview", template, "Error", "Azure_Error_Container", ACC.azure_errors, azure_error);
  }

  // ── Gauges ──
  const m365Risk   = getRiskLevelInfo(m365_highest_risk);
  const azureRisk  = getRiskLevelInfo(azure_highest_risk);

  $("#m365_risk_level_label").html(m365Risk.text);
  $("#m365_points_label").html(`Points: ${m365_achieved_points}/${m365_maxPoints}`);
  $("#azure_risk_level_label").html(azureRisk.text);
  $("#azure_points_label").html(`Points: ${azure_achieved_points}/${azure_maxPoints}`);

  const ctxM365Risk   = document.getElementById('m365_risk_level_gaugechart').getContext('2d');
  const ctxM365Points = document.getElementById('m365_points_gaugechart').getContext('2d');
  const ctxAzureRisk  = document.getElementById('azure_risk_level_gaugechart').getContext('2d');
  const ctxAzurePoints= document.getElementById('azure_points_gaugechart').getContext('2d');

  new Chart(ctxM365Risk,    createGaugeConfig(m365Risk.chartValue,  4,               getColor(m365Risk.chartValue,  4)));
  new Chart(ctxM365Points,  createGaugeConfig(m365_achieved_points, m365_maxPoints,  getColor(m365_achieved_points,  m365_maxPoints)));
  new Chart(ctxAzureRisk,   createGaugeConfig(azureRisk.chartValue, 4,               getColor(azureRisk.chartValue, 4)));
  new Chart(ctxAzurePoints, createGaugeConfig(azure_achieved_points,azure_maxPoints, getColor(azure_achieved_points, azure_maxPoints)));

  // ── Expert Mode / visibility ──
  $("#M365_NoFinding_Container, #Azure_NoFinding_Container").hide();
  $("#M365_Error_Container,     #Azure_Error_Container").hide();

  $("#loadingModal").modal('hide');

  $('#expertToggle').bootstrapToggle('enable').change(function () {
    const show = $(this).prop('checked');
    $("#M365_NoFinding_Container, #Azure_NoFinding_Container").toggle(show);
    $("#M365_Error_Container,     #Azure_Error_Container").toggle(show);
  });
}


// ─── Details tab ─────────────────────────────────────────────────────────────

function fillDetails() {
  Object.entries(tenantData.Users).forEach(([key, value]) => {
    const mfaBadge = value.isMFAEnabled
      ? '<span class="az-badge-mfa-on">MFA ✓</span>'
      : '<span class="az-badge-mfa-off">MFA ✗</span>';
    const statusBadge = value.accountEnabled
      ? '<span class="az-badge-account-on">Active</span>'
      : '<span class="az-badge-account-off">Disabled</span>';
    const lastLogin = value.signInActivity?.lastSignInDateTime
      ? new Date(value.signInActivity.lastSignInDateTime).toLocaleDateString('de-DE')
      : '—';
    $("#details_usertable > tbody").append(
      `<tr><td>${value.userPrincipalName}</td><td>${value.displayName}</td><td>${key}</td><td>${mfaBadge}</td><td>${statusBadge}</td><td>${lastLogin}</td></tr>`
    );
  });
  new DataTable('#details_usertable');

  Object.entries(tenantData.DirectoryRoles).forEach(([key, value]) => {
    const descHtml = value.description
      ? `<br><small class="text-muted">${value.description}</small>`
      : '';
    $("#details_rolestable > tbody").append(
      `<tr><td>${value.displayName}${descHtml}</td><td>${key}</td><td>${value.activeMembers.length}</td><td>${value.eligibleMembers.length}</td>` +
      `<td><button type="button" class="btn btn-primary btn-sm" onclick="showRolesDetails('${key}')">Details</button></td></tr>`
    );
  });
  new DataTable('#details_rolestable');

  Object.entries(tenantData.Applications).forEach(([key, value]) => {
    const hasPassword = value.passwordCredentials.length > 0;
    const hasKey      = value.keyCredentials.length > 0;
    const now = new Date();

    const nextPwExp = hasPassword
      ? value.passwordCredentials.map(c => new Date(c.endDateTime)).sort((a, b) => a - b)[0]
      : null;
    const pwExpired = nextPwExp && nextPwExp < now;
    const pwDateHtml = nextPwExp
      ? `<br><small class="${pwExpired ? 'az-exp-danger' : 'az-exp-date'}">${nextPwExp.toLocaleDateString('de-DE')}</small>`
      : '';
    const pwBadge = hasPassword
      ? `<span class="az-badge-cred">PW</span>${pwDateHtml}`
      : '<span class="az-cred-none">—</span>';

    const nextKeyExp = hasKey
      ? value.keyCredentials.map(c => new Date(c.endDateTime)).sort((a, b) => a - b)[0]
      : null;
    const keyExpired = nextKeyExp && nextKeyExp < now;
    const keyDateHtml = nextKeyExp
      ? `<br><small class="${keyExpired ? 'az-exp-danger' : 'az-exp-date'}">${nextKeyExp.toLocaleDateString('de-DE')}</small>`
      : '';
    const keyBadge = hasKey
      ? `<span class="az-badge-cred">KEY</span>${keyDateHtml}`
      : '<span class="az-cred-none">—</span>';

    $("#details_appregtable > tbody").append(
      `<tr><td>${value.displayName}</td><td>${key}</td><td>${value.owners.length}</td><td>${pwBadge}</td><td>${keyBadge}</td><td>${value.UserAbleToAddCreds.length}</td></tr>`
    );
  });
  new DataTable('#details_appregtable');

  Object.entries(tenantData.ServicePrincipals).forEach(([key, value]) => {
    let userConsent  = "";
    let adminConsent = "";

    const seenAdmin = [], seenUser = [];
    if (value.oauth2PermissionGrants != null) {
      value.oauth2PermissionGrants.forEach(item => {
        if (item.consentType === "AllPrincipals") {
          if (!seenAdmin.includes(item.scope)) { seenAdmin.push(item.scope); adminConsent += item.scope + "<br>"; }
        } else {
          if (!seenUser.includes(item.scope))  { seenUser.push(item.scope);  userConsent  += item.scope + "<br>"; }
        }
      });
    }
    const userConsentDisplay  = seenUser.length  > 0 ? `<span class="az-scope-count">${seenUser.length}</span>${userConsent}`   : '—';
    const adminConsentDisplay = seenAdmin.length > 0 ? `<span class="az-scope-count">${seenAdmin.length}</span>${adminConsent}` : '—';

    let appRoles = "";
    if (value.appRoleAssignments != null) {
      value.appRoleAssignments.forEach(item => {
        appRoles += appRoleIDtoNameAndResource(item.appRoleId, item.resourceId) + "<br>";
      });
    }

    $("#details_servicetable > tbody").append(
      `<tr><td>${value.appDisplayName}</td><td>${key}</td><td>${value.appOwnerOrganizationId}</td><td>${userConsentDisplay}</td><td>${adminConsentDisplay}</td><td>${appRoles}</td></tr>`
    );
  });

  $("#details_servicetable").dataTable({
    columns: [
      { width: "20%" }, { width: "10%" }, { width: "10%" },
      { width: "20%" }, { width: "20%" }, { width: "20%" }
    ]
  });
}


// ─── Role details modal ───────────────────────────────────────────────────────

function appRoleIDtoNameAndResource(appRoleId, resourceId) {
  const sp = tenantData.ServicePrincipals[resourceId];
  const role = sp.appRoles.find(r => r.id === appRoleId);
  return role ? `[${sp.appDisplayName}]::${role.value}` : "Unknown";
}

function createRoleDetailTableArray(members) {
  const result = [];
  members.forEach(member => {
    let principal = tenantData.Users[member.id]
                 ?? tenantData.Guests[member.id]
                 ?? tenantData.ServicePrincipals[member.id];

    if (principal == null) return;

    const isSP = principal.appDisplayName !== undefined;
    const type = isSP ? "Service Principal" : (tenantData.Guests[member.id] ? "Guest" : "Member");
    result.push([
      isSP ? principal.appDisplayName : principal.displayName,
      isSP ? ""                       : principal.userPrincipalName,
      isSP ? principal.appId          : principal.id,
      type
    ]);
  });
  return result;
}

function showRolesDetails(id) {
  const tableActiveMember   = new DataTable('#RolesDetailsTableAssignedUser');
  const tableEligibleMember = new DataTable('#RolesDetailsTableEliglibeUser');
  tableActiveMember.clear();
  tableEligibleMember.clear();

  const role = tenantData.DirectoryRoles[id];
  tableActiveMember.rows.add(createRoleDetailTableArray(role.activeMembers)).draw();
  tableEligibleMember.rows.add(createRoleDetailTableArray(role.eligibleMembers)).draw();

  $('#RolesDetailModalLabel').html(`Details: ${role.displayName}`);
  $('#RolesDetailModal').modal('show');
}

function initData() {
  new DataTable('#RolesDetailsTableAssignedUser');
}
